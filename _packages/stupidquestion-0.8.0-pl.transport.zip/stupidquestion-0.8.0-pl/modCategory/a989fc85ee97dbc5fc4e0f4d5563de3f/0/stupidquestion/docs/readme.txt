StupidQuestion
==============

StupidQuestion is a MODX Revolution userfriendly captcha solution for FormIt.

Installation
------------
MODX Package Management

Documentation
-------------
http://jako.github.io/StupidQuestion-Revo/

GitHub Repository
-----------------
https://github.com/Jako/StupidQuestion-Revo
