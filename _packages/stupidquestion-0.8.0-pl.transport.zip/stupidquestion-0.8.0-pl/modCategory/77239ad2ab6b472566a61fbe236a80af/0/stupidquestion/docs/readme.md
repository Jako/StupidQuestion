StupidQuestion
==============

StupidQuestion is a userfriendly captcha solution for FormIt in MODX Revolution.

Installation
------------
MODX Package Management

Documentation
-------------
http://jako.github.io/StupidQuestion-revo/

GitHub Repository
-----------------
https://github.com/Jako/StupidQuestion-revo
